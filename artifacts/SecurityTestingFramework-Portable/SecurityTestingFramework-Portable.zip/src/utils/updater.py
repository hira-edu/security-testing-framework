
class AutoUpdater:
    def __init__(self, framework):
        self.framework = framework

    def check(self):
        print("Checking for updates...")
